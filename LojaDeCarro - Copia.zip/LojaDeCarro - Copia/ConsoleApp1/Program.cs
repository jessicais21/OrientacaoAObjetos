﻿

namespace ConsoleApp1
{
    public class Program
    {
        //objeto sendo criado porque representa algo real, 
        //quando eu crio um new então 
        public static void Main(string[] args)
        {
        }      
    }
}
 




